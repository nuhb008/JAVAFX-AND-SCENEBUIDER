//package com.example.project_part_2;
//
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
//import java.net.Socket;
//
//public class Client {
//    public static void main(String[] args) {
//        String serverIp = "192.168.1."; // replace with your server's IP address
//        int port = 1269;
//
//        try (Socket socket = new Socket(serverIp, port);
//             ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
//             ObjectInputStream ois = new ObjectInputStream(socket.getInputStream())) {
//
//            // Example of sending a command to the server
//            oos.writeObject("C");  // Example command to fetch restaurant manager data
//            oos.flush();
//
//            // Read response from server
//            RestaurantsManager resManager = (RestaurantsManager) ois.readObject();
//            System.out.println("Received RestaurantsManager data from server.");
//
//            // Close the connection
//            oos.writeObject("EXIT");
//            oos.flush();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}

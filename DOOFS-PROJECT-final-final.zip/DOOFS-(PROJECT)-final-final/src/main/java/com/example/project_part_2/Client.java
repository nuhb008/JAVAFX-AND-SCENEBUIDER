//package com.example.project_part_2;
//
//import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
//import java.net.Socket;
//import java.util.ArrayList;
//import java.util.Scanner;
//
//public class Client {
//
//    private static ObjectOutputStream oos;
//    private static ObjectInputStream ois;
//
//    public static void main(String[] args) {
//        // Replace "localhost" with the server's IP address
//        String serverAddress = "192.168.0.197"; // Change this to the server's IP address
//        int port = 1269;
//
//        try {
//            // Establish connection to the server
//            Socket socket = new Socket(serverAddress, port);
//            oos = new ObjectOutputStream(socket.getOutputStream());
//            ois = new ObjectInputStream(socket.getInputStream());
//            System.out.println("Connected to the server at " + serverAddress + ":" + port);
//
//            // Run the client interface
//            runClientInterface();
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    private static void runClientInterface() {
//        Scanner scanner = new Scanner(System.in);
//        while (true) {
//            System.out.println("Enter a command (C, O, R, AGAIN, EXIT): ");
//            String command = scanner.nextLine();
//            try {
//                switch (command) {
//                    case "C":
//                        oos.writeObject("C");
//                        RestaurantsManager restaurantsManager = (RestaurantsManager) ois.readObject();
//                        System.out.println("Received RestaurantsManager: " + restaurantsManager);
//                        break;
//                    case "O":
//                        // Prompt user for customer details
//                        System.out.println("Enter user ID: ");
//                        int usrID = Integer.parseInt(scanner.nextLine());
//                        System.out.println("Enter password: ");
//                        String pass = scanner.nextLine();
//
//                        // Create and initialize the Customer object
//                        Customer customer = new Customer(usrID, pass);
//
//                        // Create sample food items
//                        ArrayList<Food> orders = new ArrayList<>();
//                        System.out.println("Enter food details for the order:");
//                        System.out.println("Enter restaurant ID: ");
//                        int restaurantId = Integer.parseInt(scanner.nextLine());
//                        System.out.println("Enter food category: ");
//                        String category = scanner.nextLine();
//                        System.out.println("Enter food name: ");
//                        String name = scanner.nextLine();
//                        System.out.println("Enter food price: ");
//                        double price = Double.parseDouble(scanner.nextLine());
//
//                        // Add the food item to the order
//                        Food foodItem = new Food(restaurantId, category, name, price);
//                        orders.add(foodItem);
//
//                        // Set the order and calculate total
//                        customer.setOrder(orders);
//                        customer.order_stringer();
//                        customer.setTotal(price); // Assuming only one item for simplicity
//
//                        // Send the customer object to the server
//                        oos.writeObject("O");
//                        oos.writeObject(customer);
//                        break;
//                    case "R":
//                        System.out.println("Enter restaurant ID: ");
//                        restaurantId = Integer.parseInt(scanner.nextLine());
//                        oos.writeObject("R");
//                        oos.writeObject(restaurantId);
//                        ArrayList<Customer> etaPathabo = (ArrayList<Customer>) ois.readObject(); // Read and process the response as needed
//                        System.out.println("Received response for restaurant ID " + restaurantId + ": " + etaPathabo);
//                        break;
//                    case "AGAIN":
//                        System.out.println("Enter restaurant ID: ");
//                        restaurantId = Integer.parseInt(scanner.nextLine());
//                        oos.writeObject("AGAIN");
//                        oos.writeObject(restaurantId);
//                        etaPathabo = (ArrayList<Customer>) ois.readObject(); // Read and process the response as needed
//                        System.out.println("Received response for restaurant ID " + restaurantId + ": " + etaPathabo);
//                        break;
//                    case "EXIT":
//                        oos.writeObject("EXIT");
//                        return;
//                    default:
//                        System.out.println("Unknown command. Please try again.");
//                }
//            } catch (IOException | ClassNotFoundException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//}

//package com.example.project_part_2;
//
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
//import java.net.Socket;
//
//public class ClientOrder {
//    public static void main(String[] args) {
//        String serverIp = "your.server.ip.address"; // replace with your server's public IP address
//        int port = 1269;
//
//        try (Socket socket = new Socket(serverIp, port);
//             ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
//             ObjectInputStream ois = new ObjectInputStream(socket.getInputStream())) {
//
//            // Send order command
//            oos.writeObject("O");
//            oos.flush();
//
//            // Create a sample customer order and send it to the server
//            Customer customer = new Customer();
//            // Fill in customer order details (This is just a placeholder. Adjust as needed)
//            customer.setOrderId(1);
//            customer.addOrderItem(new OrderItem(1, "Pizza", 2)); // Example order item
//            oos.writeObject(customer);
//            oos.flush();
//
//            // Close the connection
//            oos.writeObject("EXIT");
//            oos.flush();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}

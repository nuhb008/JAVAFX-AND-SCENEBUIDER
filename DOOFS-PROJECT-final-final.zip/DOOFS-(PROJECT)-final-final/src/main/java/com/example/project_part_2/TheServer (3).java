//package com.example.project_part_2;
//
//import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.ObjectOutputStream;
//import java.net.ServerSocket;
//import java.net.Socket;
//import java.util.ArrayList;
//import java.util.concurrent.CopyOnWriteArrayList;
//
//class ThreadHandler implements Runnable {
//
//    private Socket socket;
//    private RestaurantsManager restaurantsManager;
//    private ObjectInputStream ois;
//    private ObjectOutputStream oos;
//
//    static CopyOnWriteArrayList<Customer> ordered = new CopyOnWriteArrayList<>();
//
//    ThreadHandler(Socket socket, RestaurantsManager restaurantsManager) throws IOException {
//        this.socket = socket;
//        this.restaurantsManager = restaurantsManager;
//        oos = new ObjectOutputStream(socket.getOutputStream());
//        ois = new ObjectInputStream(socket.getInputStream());
//        new Thread(this).start();
//    }
//
//    @Override
//    public void run() {
//        try {
//            while (true) {
//                String flag = (String) ois.readObject();
//                System.out.println("Received: " + flag);
//                switch (flag) {
//                    case "C":
//                        oos.writeObject(restaurantsManager);
//                        oos.flush();
//                        break;
//                    case "O":
//                        Customer customer = (Customer) ois.readObject();
//                        ordered.add(customer);
//                        break;
//                    case "R":
//                        oos.writeObject(new ArrayList<>(ordered));
//                        oos.flush();
//                        break;
//                    case "EXIT":
//                        return;
//                }
//            }
//        } catch (IOException | ClassNotFoundException e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                socket.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//}
//
//public class Server {
//    public static void main(String[] args) throws Exception {
//        RestaurantsManager resMan = new RestaurantsManager();
//        resMan.addDatasFromFile();
//        ServerSocket serverSocket = new ServerSocket(1269);
//
//        while (true) {
//            Socket socket = serverSocket.accept();
//            System.out.println("Client connected");
//            new ThreadHandler(socket, resMan);
//        }
//    }
//}

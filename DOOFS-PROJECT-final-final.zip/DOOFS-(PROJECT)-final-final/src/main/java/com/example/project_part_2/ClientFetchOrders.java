package com.example.project_part_2;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ClientFetchOrders {
    public static void main(String[] args) {
        String serverIp = "your.server.ip.address"; // replace with your server's public IP address
        int port = 1269;

        try (Socket socket = new Socket(serverIp, port);
             ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream ois = new ObjectInputStream(socket.getInputStream())) {

            // Send fetch orders command
            oos.writeObject("R");
            oos.flush();

            // Receive the list of orders from the server
            ArrayList<Customer> orders = (ArrayList<Customer>) ois.readObject();
            System.out.println("Received orders:");
            for (Customer order : orders) {
                System.out.println(order);
            }

            // Close the connection
            oos.writeObject("EXIT");
            oos.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
